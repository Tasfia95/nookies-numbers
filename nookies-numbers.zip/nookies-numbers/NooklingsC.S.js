
document.addEventListener("DOMContentLoaded", () => {

    // Function to open a popup
    function openPopup(popupId) {
        const popup = document.getElementById(popupId);
        if (popup) popup.style.display = "flex"; // Show the popup
    }

    // Function to close a popup
    function closePopup(popupId) {
        const popup = document.getElementById(popupId);
        if (popup) popup.style.display = "none"; // Hide the popup
    }

    // Add event listeners for buttons
    document.getElementById("themeButton").addEventListener("click", () => {
        openPopup("popup-theme");
    });
    // Close the theme popup when clicking outside of it
    window.addEventListener("click", (event) => {
        const popup = document.getElementById("popup-theme");
        if (event.target === popup) {
            closePopup("popup-theme");
        }
    });

    document.getElementById("musicButton").addEventListener("click", () => {
        openPopup("popup-music");
    });
    // Close the music popup when clicking outside of it
    window.addEventListener("click", (event) => {
        const popup = document.getElementById("popup-music");
        if (event.target === popup) {
            closePopup("popup-music");
        }
    });

    //opens the instructions popup
    document.getElementById("instructionsButton").addEventListener("click", () => { 
        openPopup("popup-instructions"); 
    }); 
    // Close the instructions popup when clicking outside of it
    window.addEventListener("click", (event) => {
        const popup = document.getElementById("popup-instructions");
        if (event.target === popup) {
            closePopup("popup-instructions");
        }
    });   

    //opens the Start Game popup
    document.getElementById("startGameButton").addEventListener("click", () => { 
        openPopup("difficulty-popup"); 
    }); 
    // Close the startgame popup when clicking outside of it
    window.addEventListener("click", (event) => {
        const popup = document.getElementById("difficulty-popup");
        if (event.target === popup) {
            closePopup("difficulty-popup");
        }
    });

    // Add event listeners for popup exit buttons to close popups    
    document.querySelectorAll(".exit-popup-button").forEach((button) => {
        button.addEventListener("click", () => {
            // Find the closest popup container to close it
            const popup = button.closest(".popup");
            if (popup) {
                popup.style.display = "none"; // Close the popup
            }
        });
    });

    // // Theme toggle logic
    // const togglethemeSwitch = document.getElementById("togglethemeSwitch");
    // let isNightMode = false; // Track the current theme

    // togglethemeSwitch.addEventListener("click", () => {
    //     const body = document.body;
    //     isNightMode = !isNightMode;

    //     if (isNightMode) {
    //         body.classList.add("night-mode"); //Activate night mode
    //         togglethemeSwitch.textContent = "Switch to Light Mode"; //transforms button
    //     } else {
    //         body.classList.remove("night-mode"); //Deactivate night mode
    //         togglethemeSwitch.textContent = "Switch to Night Mode"; //transforms button
    //     }
    // });

    const themeSwitchButton = document.getElementById("togglethemeSwitch");

    // Function to toggle theme
    function toggleTheme() {
        document.body.classList.toggle("night-mode");
        const isNightMode = document.body.classList.contains("night-mode");
        localStorage.setItem("theme", isNightMode ? "night-mode" : "light-mode");
        themeSwitchButton.textContent = isNightMode ? "Switch to Light Mode" : "Switch to Night Mode";
    }

    // Load theme based on localStorage value
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "night-mode") {
        document.body.classList.add("night-mode");
        themeSwitchButton.textContent = "Switch to Light Mode";
    } else {
        themeSwitchButton.textContent = "Switch to Night Mode";
    }

    // Add event listener to toggle theme button
    themeSwitchButton.addEventListener("click", toggleTheme);
    

    
    // Music toggle logic
    const toggleMusicButton = document.getElementById("toggleMusicButton");
    const backgroundMusic = document.getElementById("backgroundMusic");
    let isMusicPlaying = false; // track music state

    // // check if music was previously enabled and volume
    // if (localStorage.getItem("isMusicPlaying") === "true") {
    //     backgroundMusic.play();
    //     isMusicPlaying = true;
    //     toggleMusicButton.textContent = "Pause Music";
    // }

    // // Restore volume if previously set
    // const savedVolume = localStorage.getItem("musicVolume");
    // if (savedVolume !== null) {
    //     backgroundMusic.volume = savedVolume;
    // }

    // Toggle music play/pause
    toggleMusicButton.addEventListener("click", () => {
        if (isMusicPlaying) {
            backgroundMusic.pause(); // Pause the music
            toggleMusicButton.textContent = "Play Music";
            // localStorage.setItem("isMusicPlaying", "false");
        } else {
            backgroundMusic.play(); // Play the music
            toggleMusicButton.textContent = "Pause Music";
            // localStorage.setItem("isMusicPlaying", "true");
        }
        isMusicPlaying = !isMusicPlaying; // Toggle music state
    });

    // Volume control for background music
    const volumeControl = document.getElementById("volumeControl");
    volumeControl.addEventListener("input", (event) => {
        backgroundMusic.volume = event.target.value; // Adjust music volume
        // localStorage.setItem("musicVolume", event.target.value);
    });



    // Music toggle logic: click sounds
    // Get references to the DOM elements for click sounds
    const buttonClickSound1 = document.getElementById("buttonClickSound1");
    const buttonClickSound2 = document.getElementById("buttonClickSound2");
    const toggleClickSoundButton = document.getElementById("toggleClickSound");
    let clickSoundEnabled = true; // Initial state: sound effects are enabled

    // Check if sound effects were previously enabled and volume 
    if (localStorage.getItem("clickSoundEnabled") === "false") { 
        clickSoundEnabled = false; 
        toggleClickSoundButton.textContent = "Enable Sound Effects"; 
    } 
    
    // Restore volume if previously set 
    const savedClickVolume = localStorage.getItem("clickVolume"); 
    if (savedClickVolume !== null) { 
        buttonClickSound1.volume = savedClickVolume; 
        buttonClickSound2.volume = savedClickVolume; 
    }

    // Function to play a random click sound
    function playRandomClickSound() {
        if (!clickSoundEnabled) {
            // If sound effects are disabled, return early
            return;
        }

        // Randomly select and play one of the click sounds
        const sounds = [buttonClickSound1, buttonClickSound2];
        const randomSound = sounds[Math.floor(Math.random() * sounds.length)];
        randomSound.currentTime = 0; // Reset to start
        randomSound.play();
    }

    // Add event listeners for all buttons to play sound on click
    document.querySelectorAll("button").forEach((button) => {
        button.addEventListener("click", (event) => {
            if (event.target.id !== "toggleClickSound") { // Avoid doubling the sound on the toggleClickSound button
                playRandomClickSound();
            }
        });
    });

    // Add event listener for the "Toggle Sound Effects" button
    toggleClickSoundButton.addEventListener("click", () => {
        clickSoundEnabled = !clickSoundEnabled; // Toggle the sound effect state
        toggleClickSoundButton.textContent = clickSoundEnabled
            ? "Disable Sound Effects"
            : "Enable Sound Effects";
        localStorage.setItem("clickSoundEnabled", clickSoundEnabled);
        playRandomClickSound(); // Play the sound when toggling
    });

    // Update click sound volume based on slider input 
    clickVolumeControl.addEventListener("input", () => { 
        buttonClickSound1.volume = clickVolumeControl.value; // set volume for the first click sound
        buttonClickSound2.volume = clickVolumeControl.value;  // set volume for the second click sound
        localStorage.setItem("clickVolume", volume);
    }); 

});
