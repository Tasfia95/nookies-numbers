// GAME PLAY CODE 
// PLS DON'T CHANGE ANY LOGICAL PART

let maxAttempts = 3;

let attemptCounter = 0;

let secretNumber = 0;

let userScore = 0;

var currentMode; 

var isGameActive = false; // NEW: Flag to track if the game is ongoing

// Initialize game stats display
function updateGameStats() {
    document.getElementById('attempts-left').innerText = maxAttempts - attemptCounter; // Update attempts left
    document.getElementById('current-score').innerText = userScore; // Update current score
}

// Read difficulty level from URL
window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const mode = urlParams.get('mode'); // Get mode from query parameter
    if (mode) {
        selectMode(mode); // Automatically set the mode if provided
    }
};

// Mode selection (easy, medium, hard)

function selectMode(mode) {

    if (isGameActive) { // NEW: Prevent changing mode during an active game
        document.getElementById('feedback').innerText = "You can't change the mode during a game!";
        return; // Exit if trying to change mode while game is active
    }

    currentMode = mode; 

    if (mode === 'Easy') 
    {
        secretNumber = Math.floor(Math.random() * 10) + 1; // Generate Random Number from 1 - 10 
    } 

    else if (mode === 'Medium') 
    {
        secretNumber = Math.floor(Math.random() * 20) + 1; // Generate Random Number from 1 - 20 
    } 
    
    else if (mode === 'Hard') 
    {
        secretNumber = Math.floor(Math.random() * 50) + 1; // Generate Random Number from 1 - 50
    }

      // NEW: Set game as active after selecting the mode
      isGameActive = true;

    // notify player  that the game has started once difficulty mode has been chosen 
    document.getElementById('feedback').innerText = `Game Mode Set to ${mode}, Make your guess!`;
    // get rid of this after testing 
    document.getElementById('show-num').innerText = secretNumber; 
    updateGameStats(); // Update stats at the start of the game

}

// Handle outcomes

function handleGuess() {

    //  Prevent guessing if the game has ended 
    if (!isGameActive) { 
        document.getElementById('feedback').innerText = "The game has ended. Please restart to play again!";
        return; // Exit if the game is inactive
    }

    const userGuess = parseInt(document.getElementById('userGuess').value); // get value from the input field and store it into userGuess

 
    if (isNaN(userGuess))
    {
        document.getElementById('feedback').innerText = "Enter A Number To Start!";
        return;
    }

    attemptCounter++; // increment counter everytime they guess
    updateGameStats(); // Update stats after each attempt

    if (attemptCounter >= maxAttempts) {
        endGame(false);
        return; // Exit if the game should end
    }
    
    if (userGuess === secretNumber)  // check if number is userGuess is correct
    {
        userScore++; // increment the score 
        endGame(true); // end the game so we can restart with a new Number 
    } 

    else if (userGuess > secretNumber) // check if userGuess is higher thank the number 
    {
        document.getElementById('feedback').innerText = "Your guess is too high.";
    } 

    else if (userGuess < secretNumber) // check if userGuess is lower than the number 
    {
        document.getElementById('feedback').innerText = "Your guess is too low.";
    }

    else if (attemptCounter >= maxAttempts && userGuess !== secretNumber) { // if the user maxxed out attempts and didnt guess the number successfully 
        endGame(false);
    }


}

// End the Game and Display Results
/*
function endGame(flag) {

    isGameActive = false; // NEW: Set the game as inactive to prevent further guesses

    if (flag)  // if flag == true, meaning the number was guessed correctly, let the player know and their score 
    {
        document.getElementById('score').innerText = `You guessed the correct number! Your current score is: ${userScore}`;
    } 

    else  // if they lost, let them know what the number was and their current score 
    {
        document.getElementById('score').innerText = `You've used all your attempts. The correct number was: ${secretNumber}. Your current score is: ${userScore}`;
        document.getElementById('feedback').innerText - "but you can restart the game to play with us again!"
    }
}
*/ 

// End the Game and Display Popups
function endGame(flag) {
    isGameActive = false;

    // Populate the correct number and score in both popups
    document.getElementById('correct-number-correct').innerText = secretNumber;
    document.getElementById('score-correct').innerText = userScore;
    document.getElementById('correct-number-wrong').innerText = secretNumber;
    document.getElementById('score-wrong').innerText = userScore;

    if (flag) {
        //document.getElementById('score').innerText = You guessed the correct number! Your current score is: ${userScore};
        openPopup('popup-correct'); // Show the correct popup
    } else {
        //document.getElementById('score').innerText = You've used all your attempts. The correct number was: ${secretNumber}. Your current score is: ${userScore};
        openPopup('popup-wrong'); // Show the wrong popup
    }
}

// Function to open a popup
function openPopup(popupId) {
    const popup = document.getElementById(popupId);
    if (popup) popup.style.display = "flex"; // Show the popup

    // Play sound based on popup type 
    if (popupId === "popup-correct") { 
        playSound("winSound"); 
    } else if (popupId === "popup-wrong") { 
        playSound("loseSound");
    }
}

// Function to play a sound by element ID
function playSound(soundId) {
    const sound = document.getElementById(soundId);
    if (sound) {
        sound.currentTime = 0; // Reset to start
        sound.play();
    }
}

// Function to close a popup
function closePopup(popupId) {
    const popup = document.getElementById(popupId);
    if (popup) popup.style.display = "none"; // Hide the popup
}




// Function to close a popup
function closePopup(popupId) {
    const popup = document.getElementById(popupId);
    if (popup) popup.style.display = "none"; // Hide the popup
}

// // function to handle Continue Game button so the user can keep playing 
// function handleContinue() {
//     if (!isGameActive) 
//     {
//         attemptCounter = 0; // Reset attempts
//         selectMode(currentMode); // calling selectMode function again to regnerate a new nummm
//         isGameActive = true; // Starting the game again
//         document.getElementById('feedback').innerText = `New number generated for ${currentMode} mode. Make your guess!`;
    
//     }
//     // closing the popups 
//     closePopup('popup-correct');
//     closePopup('popup-wrong');
// }

// Function to set character images on the left 
function setCharacterImageLeft() { 
    const characterImagesLeft = [ 
        "images/character2.webp", 
        "images/character8.png", 
        "images/character10.png",
        "images/character14.png",
        "images/character19.png",
        "images/character22.png",
        "images/character24.png",
        "images/character25.png",
    ]; 
    const randomIndex = Math.floor(Math.random() * characterImagesLeft.length); 
    const characterImageLeft = document.getElementById("characterImageLeft"); 
    characterImageLeft.style.backgroundImage = `url(${characterImagesLeft[randomIndex]})`; 
} 

// Function to set character images on the right 
function setCharacterImageRight() { 
    const characterImagesRight = [ 
        "images/character1.webp", 
        "images/character3.avif", 
        "images/character7.png", 
        "images/character9.webp", 
        "images/character11.png",
        "images/character12.png",
        "images/character13.png",
        "images/character16.png",
        "images/character21.png",
        "images/character23.webp"
    ]; 
    const randomIndex = Math.floor(Math.random() * characterImagesRight.length); 
    const characterImageRight = document.getElementById("characterImageRight"); 
    characterImageRight.style.backgroundImage = `url(${characterImagesRight[randomIndex]})`; 
} 

// Initialize character images on page load 
setCharacterImageLeft(); 
setCharacterImageRight();

// function to handle Continue Game button so the user can keep playing 
function handleContinue() {
    // closing the popups first 
    closePopup('popup-correct');
    closePopup('popup-wrong');

    attemptCounter = 0; // Reset attempts
    selectMode(currentMode); // calling selectMode function again to regnerate a new number
    isGameActive = true; // Starting the game again
    document.getElementById('feedback').innerText = `New number generated for ${currentMode} mode. Make your guess!`;
    
    // Reset character images when continuing the game 
    setCharacterImageLeft(); 
    setCharacterImageRight();
}


// Handle "End Game" action
function handleEndGame() {
    userScore = 0; // Reset the score
    restartGame(); // Restart the game to allow mode selection
    window.location.href = 'main-menu.html';
    closePopup('popup-correct'); // Hide the correct popup
    closePopup('popup-wrong'); // Hide the wrong popup
}

// Restart the game
/*
    - set score to 0 
    - set attempts to 0
    - set game is active to Flase (can reset the mode again)
    - say the game reset
*/

function restartGame() {
    // userScore = 0; Score does not reset if they restart the game because they are still playing the game.
    // score only resets if they exit to the main menu.  
    attemptCounter = 0;
    isGameActive = false; 
    document.getElementById('feedback').innerText = "Game reset. Choose a mode to start playing again.";
    document.getElementById('score').innerText = "";
    updateGameStats(); // Reset stats display
}

// Function to show the Exit Confirmation Popout
function openExitPopup() {
    const popup = document.getElementById('exit-popup');
    if (popup) popup.style.display = 'flex'; // Show the popup
}

// Function to close any popup
function closePopup(popupId) {
    const popup = document.getElementById(popupId);
    if (popup) popup.style.display = 'none'; // Hide the popup
}

// Function to reset the game and navigate to the main menu
function exitToMainMenu() {
    userScore = 0;
    attemptCounter = 0;
    isGameActive = false;
    // Redirect to the main menu to select a new mode and start playing again.
    window.location.href = 'main-menu.html'; // working and exits to the main menu. 
}



// Help Area // Instructions // Hint Button

// Function to provide game instructions
function provideInstructions() {
    const feedbackElement = document.getElementById('help-feedback');

    feedbackElement.innerHTML = `
        <h5>Welcome to Nookies Numbers! Here's how to play:</h5>
        <ul>
            <li>Choose a difficulty mode to generate a secret number.</li>
            <li>You have exactly 3 attempts to guess the secret number.</li>
            <li>After each guess, you'll be told if your guess was too high or too low.</li>
            <li>Use the Hint button for help: it will tell you if the number is even or odd, and give a small range around the number, but You Can Only Use It Once Each Round!</li>
            <li>Your score increases if you continue to play the game and guess the correct number.</li>
            <li>If you decide to exit the game, the mode and score will all reset! So you can come back and play again once you're ready!</li>
            <li>Good luck!</li>
        </ul>
    `;
}



// Function to provide a hint
function provideHint() {

    if (attemptCounter >= maxAttempts) 
    {
        document.getElementById('help-feedback').innerHTML = `
            No more hints are available as you've used all your attempts.
        `;
        return; // Exit the function
    }

    // Determine if the number is even or odd
    let evenOrOdd = (secretNumber % 2 === 0) ? "even" : "odd";
    // Calculate the hint range (2 numbers above and below the secret number)
    let lowerBound = Math.max(secretNumber - 3, 1); // the lowest bound is always 1 (that way we never go into the negatives)
    let upperBound = Math.max(secretNumber + 3, 1);

    document.getElementById('help-feedback').innerHTML = `
        Hint: The number is ${evenOrOdd} and is between ${lowerBound} and ${upperBound}.
    `;

}

// UPDATED: Function to open the help popup
function openHelpPopup() {
    const popup = document.getElementById('help-popup');
    if (popup) {
        popup.style.display = 'flex'; // Ensure the popup is displayed with flex to make it visible
    }
}

// UPDATED: Function to close the help popup
function closeHelpPopup() {
    const popup = document.getElementById('help-popup');
    if (popup) {
        popup.style.display = 'none'; // Hide the popup
    }
    document.getElementById('help-feedback').innerText = ""; // Clear feedback for hints/instructions
}